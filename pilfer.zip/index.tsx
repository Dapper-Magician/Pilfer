import React, { useEffect, useReducer, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Type, Chat } from "@google/genai";
import {
    ReconResult, PilferResult, RefactorResult, ComparativeResult, BlueprintResult,
    UnitTestResult, LiveResult, AppState, AuditType, FrameworkTarget,
    StylingTarget, StateTarget, Persona, AppAction
} from './types';
import {
    ReconCard, ResultCard, RefactorResultCard, ComparativeResultCard, BlueprintResultCard,
    StreamingResultCard, HistoryPanel, CommandPalette, SettingsPanel, SafehouseModal
} from './components';


// --- HELPERS ---
function extractAndParseJson<T>(text: string): T {
    const jsonStart = text.indexOf('{');
    const arrayStart = text.indexOf('[');
    
    let startIndex = -1;
    if (jsonStart !== -1 && arrayStart !== -1) {
        startIndex = Math.min(jsonStart, arrayStart);
    } else if (jsonStart !== -1) {
        startIndex = jsonStart;
    } else {
        startIndex = arrayStart;
    }

    if (startIndex === -1) {
        console.warn("No JSON object or array found in text, returning as is.", text);
        return {} as T; 
    }

    const jsonEnd = text.lastIndexOf('}');
    const arrayEnd = text.lastIndexOf(']');
    const endIndex = Math.max(jsonEnd, arrayEnd);

    if (endIndex === -1) {
         console.warn("Incomplete JSON object or array, returning as is.", text);
         return {} as T;
    }
    
    const jsonString = text.substring(startIndex, endIndex + 1);

    try {
        return JSON.parse(jsonString);
    } catch (e) {
        console.error("Failed to parse extracted JSON string:", jsonString);
        throw new Error("The AI response was not in a valid JSON format, even after extraction.");
    }
}


// --- AI & API CONFIG ---
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const reconSchema = {
    type: Type.OBJECT,
    properties: {
        colorPalette: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { hex: { type: 'string' }, name: { type: 'string' } } } },
        typography: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { fontFamily: { type: 'string' }, usage: { type: 'string' } } } },
        coreStyles: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { name: { type: 'string' }, code: { type: 'string' } } } },
        pageArchitecture: {
            type: Type.STRING,
            description: "A stringified JSON array representing a nested tree of identified page components. Each node in the tree should be an object with a 'name' (string) and an optional 'children' (array of nodes) property."
        }
    }
};
// Schemas for other operations...
const pilferSchema = { type: Type.OBJECT, properties: { name: { type: Type.STRING }, techStack: { type: Type.ARRAY, items: { type: Type.STRING } }, architecturalNotes: { type: Type.STRING }, code: { type: Type.STRING }, rationale: { type: Type.STRING }, tags: { type: Type.ARRAY, items: { type: Type.STRING } } } };
const refactorSchema = { type: Type.OBJECT, properties: { name: { type: Type.STRING }, explanation: { type: Type.STRING }, refactoredCode: { type: Type.STRING }, tags: { type: Type.ARRAY, items: { type: Type.STRING } } } };
const comparativeSchema = { type: Type.OBJECT, properties: { summary: { type: Type.STRING }, subject1: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, notes: { type: Type.STRING } } }, subject2: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, notes: { type: Type.STRING } } } } };
const blueprintSchema = { type: Type.OBJECT, properties: { name: { type: Type.STRING }, explanation: { type: Type.STRING }, diagram: { type: Type.STRING, description: "A Mermaid.js graph syntax string for a flowchart (graph TD)." }, tags: { type: Type.ARRAY, items: { type: Type.STRING } } } };
const unitTestSchema = { type: Type.OBJECT, properties: { testFramework: { type: Type.STRING }, tests: { type: Type.STRING }, explanation: { type: Type.STRING } } };


// --- STATE MANAGEMENT (useReducer) ---
const initialState: AppState = {
    appState: 'IDLE',
    url: '',
    reconResult: null,
    deepDiveResults: {},
    comparativeResults: {},
    refactorResults: {},
    blueprintResults: {},
    sessionHistory: [],
    theme: 'default',
    fontSize: 16,
    layout: 'default',
    directive: '',
    pageSource: '',
    code: '',
    apiDocs: '',
    compareCode1: '',
    compareCode2: '',
    compareDirective: '',
    analysisMode: 'single',
    auditType: 'heist',
    frameworkTarget: 'react',
    stylingTarget: 'tailwind',
    stateTarget: 'hooks',
    persona: 'professor',
    error: null,
    chat: null,
    chatHistory: [],
    isHistoryOpen: false,
    isCommandPaletteOpen: false,
    isSettingsOpen: false,
    safehouseState: { isOpen: false, component: null },
    liveResult: null,
    heistPlan: null,
};

function appReducer(state: AppState, action: AppAction): AppState {
    switch (action.type) {
        case 'SET_FIELD':
            return { ...state, [action.payload.field]: action.payload.value };
        case 'SET_APP_STATE':
            return { ...state, appState: action.payload };
        case 'SET_CHAT':
            return { ...state, chat: action.payload };
        case 'LOAD_SESSION':
            return { ...state, ...action.payload };
        case 'STREAM_START':
            return { ...state, appState: 'HEISTING', error: null, liveResult: { ...action.payload, content: '' } };
        case 'STREAM_UPDATE':
            return state.liveResult ? { ...state, liveResult: { ...state.liveResult, content: action.payload } } : state;
        case 'STREAM_END':
            return { ...state, liveResult: null, appState: 'IDLE' };
        case 'SET_RECON_RESULT':
            return { ...state, reconResult: action.payload };
        case 'ADD_RESULT':
            const { id, type, result } = action.payload;
            const newHistory = [...state.sessionHistory, { id, type, title: result.name || `Compare: ${state.compareDirective.substring(0,20)}...` }];
            switch (type) {
                case 'heist': return { ...state, sessionHistory: newHistory, deepDiveResults: { ...state.deepDiveResults, [id]: result } };
                case 'refactor': return { ...state, sessionHistory: newHistory, refactorResults: { ...state.refactorResults, [id]: result } };
                case 'blueprint': return { ...state, sessionHistory: newHistory, blueprintResults: { ...state.blueprintResults, [id]: result } };
                case 'Compare': return { ...state, sessionHistory: newHistory, comparativeResults: { ...state.comparativeResults, [id]: result } };
                default: return state;
            }
        case 'ADD_HISTORY_ENTRY':
             return { ...state, sessionHistory: [...state.sessionHistory, action.payload]};
        case 'SET_ERROR':
            return { ...state, error: action.payload, appState: 'IDLE' };
        case 'TOGGLE_PANEL':
            switch(action.payload.panel) {
                case 'history': return { ...state, isHistoryOpen: action.payload.isOpen };
                case 'command': return { ...state, isCommandPaletteOpen: action.payload.isOpen };
                case 'settings': return { ...state, isSettingsOpen: action.payload.isOpen };
            }
        case 'OPEN_SAFEHOUSE':
            return { ...state, safehouseState: { isOpen: true, component: action.payload } };
        case 'CLOSE_SAFEHOUSE':
            return { ...state, safehouseState: { isOpen: false, component: null } };
        case 'RESET_SESSION':
            return { ...initialState };
        case 'SET_HEIST_PLAN':
            return { ...state, heistPlan: action.payload };
        case 'CLEAR_HEIST_PLAN':
            return { ...state, heistPlan: null, appState: 'IDLE' };
        default:
            return state;
    }
}

// --- ASYNC HELPERS ---
async function streamAndProcess<T>(
    prompt: string,
    config: any,
    type: LiveResult['type'],
    title: string,
    chat: Chat,
    dispatch: React.Dispatch<AppAction>
): Promise<(T & { id: string }) | null> {
    const resultId = `${type}-${Date.now()}`;
    dispatch({ type: 'STREAM_START', payload: { id: resultId, type, title } });
    try {
        const stream = await chat.sendMessageStream({ message: prompt, config });
        let accumulatedText = "";
        for await (const chunk of stream) {
            accumulatedText += chunk.text;
            dispatch({ type: 'STREAM_UPDATE', payload: accumulatedText });
        }
        
        const newHistory = await chat.getHistory();
        dispatch({ type: 'SET_FIELD', payload: { field: 'chatHistory', value: newHistory }});

        const parsedResult = extractAndParseJson<T>(accumulatedText);
        
        if(type !== 'Recon') { // Recon has its own history/result update logic
            const historyEntry = { id: resultId, type, title };
            dispatch({ type: 'ADD_HISTORY_ENTRY', payload: historyEntry });
        }
        
        return { ...parsedResult, id: resultId };

    } catch (e: any) {
        console.error(e);
        dispatch({ type: 'SET_ERROR', payload: `Heist Failed: ${e.message}` });
        return null;
    } finally {
        dispatch({ type: 'STREAM_END' });
    }
}

// --- APP COMPONENT ---
function App() {
    const [state, dispatch] = useReducer(appReducer, initialState);
    const {
        appState, url, reconResult, deepDiveResults, comparativeResults, refactorResults, blueprintResults,
        sessionHistory, theme, fontSize, layout, directive, pageSource, code, apiDocs, compareCode1, compareCode2,
        compareDirective, analysisMode, auditType, frameworkTarget, stylingTarget, stateTarget, persona,
        error, chat, isHistoryOpen, isCommandPaletteOpen, isSettingsOpen, safehouseState, liveResult, heistPlan
    } = state;

    const [planRefinement, setPlanRefinement] = useState('');

    // --- EFFECTS ---
    useEffect(() => {
        try {
            const savedSession = localStorage.getItem('pilferSession');
            if (savedSession) {
                const parsed = JSON.parse(savedSession);
                dispatch({ type: 'LOAD_SESSION', payload: parsed });
            }
        } catch (e) {
            console.error("Failed to parse saved session", e);
            localStorage.removeItem('pilferSession');
        }
    }, []);

    useEffect(() => {
        const persistableState = {
            url, reconResult, deepDiveResults, comparativeResults, refactorResults,
            blueprintResults, sessionHistory, theme, fontSize, layout, chatHistory: state.chatHistory,
        };
        localStorage.setItem('pilferSession', JSON.stringify(persistableState));
    }, [url, reconResult, deepDiveResults, comparativeResults, refactorResults, blueprintResults, sessionHistory, theme, fontSize, layout, state.chatHistory]);

    useEffect(() => {
        if (!chat) {
            const newChat = ai.chats.create({ model: 'gemini-2.5-flash', history: state.chatHistory || [] });
            dispatch({ type: 'SET_CHAT', payload: newChat });
        }
    }, [chat, state.chatHistory]);
    
     useEffect(() => {
        document.body.dataset.theme = theme;
        document.body.dataset.layout = layout;
        document.documentElement.style.fontSize = `${fontSize}px`;
    }, [theme, fontSize, layout]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                dispatch({ type: 'TOGGLE_PANEL', payload: { panel: 'command', isOpen: !isCommandPaletteOpen }});
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isCommandPaletteOpen]);


    // --- HANDLERS ---
    const setField = (field: keyof AppState, value: any) => dispatch({ type: 'SET_FIELD', payload: { field, value } });

    const handleCommand = (cmd: string) => {
        switch (cmd) {
            case 'run_heist': analysisMode === 'single' && handleDeepDive(); break;
            case 'run_compare': analysisMode === 'compare' && handleCompare(); break;
            case 'toggle_mode': setField('analysisMode', analysisMode === 'single' ? 'compare' : 'single'); break;
            case 'export': handleExportMarkdown(); break;
            case 'reset': handleResetSession(); break;
        }
        dispatch({ type: 'TOGGLE_PANEL', payload: { panel: 'command', isOpen: false } });
    };

    const handleQuickHeist = (tech: string) => {
        const newDirective = `Based on your knowledge of ${url || 'the target site'}, deconstruct another interesting component that uses ${tech}.`;
        setField('directive', newDirective);
        document.getElementById('directive')?.focus();
    };
    
    const handleComponentSelect = (componentName: string) => {
        setField('directive', `Deconstruct the "${componentName}" component from the target.`);
        document.getElementById('directive')?.focus();
    }
    
    const getPersonaInstruction = () => ({
        ghost: "Be extremely concise. Provide code that is minimal and self-explanatory. Omit lengthy explanations unless absolutely necessary.",
        professor: "Be a teacher. Explain the 'why' behind your analysis and code. Use comments to clarify complex parts. Your goal is to educate the user.",
        cleaner: "Be a production expert. The code you provide must be robust, performant, and include error handling. Add professional documentation like JSDoc comments.",
    })[persona];

    const handleRecon = async () => {
        if (!chat) return;
        dispatch({ type: 'SET_APP_STATE', payload: 'CASING' });
        const contextInstruction = pageSource
            ? `You will analyze the provided HTML source code for the website at the URL "${url}".\n\`\`\`html\n${pageSource}\n\`\`\``
            : `You do not "visit" or "scrape" the URL. Instead, you leverage your extensive knowledge of this website at "${url}", its public design system, and common web patterns to deduce its core design assets.`;

        const prompt = `You are a master digital thief... Your task is to perform reconnaissance...
        **Persona:** ${getPersonaInstruction()}
        **Target:** ${url}
        **Reconnaissance Directive:** ${contextInstruction}
        Return your findings as a single JSON object. The 'pageArchitecture' property must be a stringified JSON array of component nodes.`;
        
        const result = await streamAndProcess<any>(prompt, { responseMimeType: 'application/json', responseSchema: reconSchema }, 'Recon', `Recon: ${url}`, chat, dispatch);
        if (result) {
            const parsedResult: ReconResult = { ...result, pageArchitecture: JSON.parse(result.pageArchitecture || '[]') };
            dispatch({ type: 'ADD_HISTORY_ENTRY', payload: {id: result.id, type: 'Recon', title: `Recon: ${url}`} });
            dispatch({ type: 'SET_RECON_RESULT', payload: parsedResult });
        }
    };

    const handlePlanHeist = async () => {
        if (!chat) return;
        dispatch({ type: 'SET_APP_STATE', payload: 'PLANNING_HEIST' });

        const planPrompt = `You are a world-class senior frontend engineer planning a "heist." Your goal is to create a concise, step-by-step plan to achieve the user's objective. Do NOT write any code. Just describe the approach in plain text.
        **Persona:** ${getPersonaInstruction()}
        **Target Context:** URL: ${url}
        ${reconResult ? `Recon Data:\n\`\`\`json\n${JSON.stringify({ colorPalette: reconResult.colorPalette, typography: reconResult.typography, coreStyles: reconResult.coreStyles }, null, 2)}\n\`\`\`` : ''}
        **Heist Objective:** ${directive}
        **Technical Specifications:** Framework: ${frameworkTarget}, Styling: ${stylingTarget}, State: ${stateTarget}
        ${apiDocs ? `**Contextual Documentation:**\n\`\`\`\n${apiDocs}\n\`\`\`` : ''}
        **Deliverables:** Respond with a plain-text, step-by-step plan for how you will build this component. For example: "1. Create a new React component. 2. Use useState for the dropdown state. 3. Use useEffect to handle outside clicks."`;

        try {
            const response = await chat.sendMessage({ message: planPrompt });
            dispatch({ type: 'SET_HEIST_PLAN', payload: { plan: response.text, isAwaitingConfirmation: true } });
            dispatch({ type: 'SET_APP_STATE', payload: 'AWAITING_CONFIRMATION' });
            const newHistory = await chat.getHistory();
            dispatch({ type: 'SET_FIELD', payload: { field: 'chatHistory', value: newHistory } });
        } catch (e: any) {
            console.error(e);
            dispatch({ type: 'SET_ERROR', payload: `Planning Failed: ${e.message}` });
            dispatch({ type: 'SET_APP_STATE', payload: 'IDLE' });
        }
    };
    
    const handleExecuteHeist = async () => {
        if (!chat) return;

        const title = `Heist: ${directive.substring(0, 30)}...`;
        const userMessage = planRefinement || "That plan looks good. Proceed with the heist.";
        const executionPrompt = `${userMessage}\n\nNow, execute the plan and provide the final code as a single JSON object. Your response MUST follow the required JSON schema. For React, the main component MUST be named \`PilferedComponent\`.`;

        const result = await streamAndProcess<PilferResult>(executionPrompt, { responseMimeType: 'application/json', responseSchema: pilferSchema }, 'heist', title, chat, dispatch);
        
        if (result) {
            dispatch({ type: 'ADD_RESULT', payload: { id: result.id, type: 'heist', result } });
        }
        dispatch({ type: 'CLEAR_HEIST_PLAN' });
        setPlanRefinement('');
    };


    const handleDeepDive = async () => {
        if (!chat) return;
        let currentAuditType = (auditType === 'heist' && code) ? 'refactor' : auditType;
        if (currentAuditType === 'refactor') setField('auditType', 'refactor');
        
        switch (currentAuditType) {
            case 'heist':
                await handlePlanHeist();
                break;
            case 'refactor': {
                const title = `Refactor: ${directive.substring(0, 30)}...`;
                const prompt = `You are an expert code reviewer...
                **Persona:** ${getPersonaInstruction()}
                **Code to Refactor:** \`\`\`${code}\`\`\`
                **Refactoring Directive:** ${directive}
                ${apiDocs ? `**Contextual Documentation:**\n\`\`\`\n${apiDocs}\n\`\`\`` : ''}
                **Deliverables:** Return a single JSON object with the refactored code and a clear explanation...`;
                const result = await streamAndProcess<any>(prompt, { responseMimeType: 'application/json', responseSchema: refactorSchema }, currentAuditType, title, chat, dispatch);
                if (result) {
                    dispatch({ type: 'ADD_RESULT', payload: { id: result.id, type: currentAuditType, result } });
                }
                break;
            }
            case 'blueprint': {
                const title = `Blueprint: ${directive.substring(0, 30)}...`;
                const prompt = `You are a software architect...
                **Persona:** ${getPersonaInstruction()}
                **Architectural Objective:** ${directive}
                 ${apiDocs ? `**Contextual Documentation:**\n\`\`\`\n${apiDocs}\n\`\`\`` : ''}
                **Deliverables:** Return a single JSON object... a 'diagram' field containing ONLY the Mermaid.js graph syntax...`;
                const result = await streamAndProcess<any>(prompt, { responseMimeType: 'application/json', responseSchema: blueprintSchema }, currentAuditType, title, chat, dispatch);
                if (result) {
                    dispatch({ type: 'ADD_RESULT', payload: { id: result.id, type: currentAuditType, result } });
                }
                break;
            }
            default:
                dispatch({ type: 'SET_ERROR', payload: `Audit type '${currentAuditType}' is not implemented.` });
                return;
        }
    };
    
    const handleCompare = async () => {
        if (!chat) return;
        const title = `Compare: ${compareDirective.substring(0, 30)}...`;
        const prompt = `You are a principal engineer specializing in comparative code analysis...
        **Persona:** ${getPersonaInstruction()}
        **Comparison Directive:** ${compareDirective}
        **Subject 1:**\n\`\`\`\n${compareCode1}\n\`\`\`
        **Subject 2:**\n\`\`\`\n${compareCode2}\n\`\`\`
        **Deliverables:** Return a single JSON object.`;
        
        const result = await streamAndProcess<ComparativeResult>(prompt, { responseMimeType: 'application/json', responseSchema: comparativeSchema }, 'Compare', title, chat, dispatch);
        if (result) {
            dispatch({ type: 'ADD_RESULT', payload: { id: result.id, type: 'Compare', result } });
        }
    };

    const handleGenerateTests = async (codeToTest: string): Promise<UnitTestResult | null> => {
        const prompt = `You are a testing expert. Analyze the provided component code and generate a suite of unit tests using Jest and React Testing Library...
        **Component Code:** \`\`\`${codeToTest}\`\`\`
        **Deliverables:** Return a single JSON object...`;
        try {
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: 'application/json', responseSchema: unitTestSchema }});
            return extractAndParseJson<UnitTestResult>(response.text);
        } catch (e: any) {
            dispatch({ type: 'SET_ERROR', payload: `Failed to generate tests: ${e.message}` });
            return null;
        }
    };
    
    const handleResetSession = () => {
        if (window.confirm("Are you sure you want to reset the entire session? This cannot be undone.")) {
            localStorage.removeItem('pilferSession');
            dispatch({ type: 'RESET_SESSION' });
        }
    };

    const handleExportMarkdown = () => { /* ... implementation unchanged ... */ };
    
    const renderedHistory = useMemo(() => sessionHistory.slice().reverse(), [sessionHistory]);

    const getHeistButtonText = () => {
        if (appState === 'PLANNING_HEIST') return 'Planning...';
        if (appState === 'AWAITING_CONFIRMATION') return 'Awaiting Confirmation';
        if (appState === 'HEISTING') return 'Heisting...';
        if (auditType === 'heist') return 'Plan Heist';
        return 'Run Deep Dive';
    };
    
    const isFormDisabled = appState !== 'IDLE' || heistPlan?.isAwaitingConfirmation;

    return (
        <>
            <h1>Pilfer</h1>
            <div className="top-controls">
                <div className="mode-toggle">
                    <button className={analysisMode === 'single' ? 'active' : ''} onClick={() => setField('analysisMode', 'single')}>Single</button>
                    <button className={analysisMode === 'compare' ? 'active' : ''} onClick={() => setField('analysisMode', 'compare')}>Compare</button>
                </div>
                <div className="utility-buttons">
                    <button onClick={() => dispatch({type: 'TOGGLE_PANEL', payload: {panel: 'history', isOpen: true}})}>Logbook</button>
                    <button onClick={() => dispatch({type: 'TOGGLE_PANEL', payload: {panel: 'command', isOpen: true}})}>Cmd (⌘K)</button>
                    <button onClick={() => dispatch({type: 'TOGGLE_PANEL', payload: {panel: 'settings', isOpen: true}})}>Settings</button>
                </div>
            </div>

            <div className={`main-content ${appState === 'HEISTING' ? 'heisting' : ''}`}>
                 {heistPlan?.isAwaitingConfirmation && (
                    <div className="heist-plan-card scan-in-animation">
                        <h3>Heist Plan Proposed</h3>
                        <p>{heistPlan.plan}</p>
                        <div className="form-group">
                            <label htmlFor="planRefinement">Refine Plan (Optional)</label>
                            <textarea
                                id="planRefinement"
                                value={planRefinement}
                                onChange={e => setPlanRefinement(e.target.value)}
                                placeholder="e.g., No, use a CSS class for the open state instead of JS."
                            />
                        </div>
                        <div className="heist-plan-actions">
                            <button onClick={handleExecuteHeist} disabled={appState !== 'AWAITING_CONFIRMATION'}>
                                {planRefinement ? 'Proceed with Refinements' : 'Proceed with Plan'}
                            </button>
                            <button className="cancel-btn" onClick={() => dispatch({ type: 'CLEAR_HEIST_PLAN' })} disabled={appState !== 'AWAITING_CONFIRMATION'}>
                                Cancel
                            </button>
                        </div>
                    </div>
                )}
                <div className={`input-form ${isFormDisabled ? 'disabled' : ''}`}>
                    {analysisMode === 'single' ? (
                        <>
                            <div className="form-group"><label htmlFor="url">Target URL</label><input type="text" id="url" value={url} onChange={e => setField('url', e.target.value)} placeholder="https://example.com" /></div>
                            <div className="form-group"><label htmlFor="pageSource">Page Source (HTML - Optional)</label><textarea id="pageSource" value={pageSource} onChange={e => setField('pageSource', e.target.value)} placeholder="Paste HTML source for high-fidelity recon..." /></div>
                            <button onClick={handleRecon} disabled={!url || isFormDisabled}>{appState === 'CASING' ? 'Casing...' : 'Case The Joint'}</button>
                            
                            <div className="section-title">Deep Dive</div>
                            <div className="form-group"><label htmlFor="directive">Heist Objective</label><textarea id="directive" value={directive} onChange={e => setField('directive', e.target.value)} placeholder="e.g., Yoink the hero section..." /></div>
                            <div className="form-group"><label htmlFor="code">Code (For Refactor/Blueprint)</label><textarea id="code" value={code} onChange={e => setField('code', e.target.value)} placeholder="Paste code here to refactor..." /></div>
                            <div className="form-group"><label htmlFor="apiDocs">API Context / Docs (Optional)</label><textarea id="apiDocs" value={apiDocs} onChange={e => setField('apiDocs', e.target.value)} placeholder="Paste relevant library docs here for higher accuracy..." /></div>
                            <div className="form-group-inline">
                                <div className="form-group"><label>Audit Type</label><select value={auditType} onChange={e => setField('auditType', e.target.value as AuditType)}><option value="heist">Heist</option><option value="refactor">Refactor</option><option value="blueprint">Blueprint</option></select></div>
                                <div className="form-group"><label>Persona</label><select value={persona} onChange={e => setField('persona', e.target.value as Persona)}><option value="professor">Professor</option><option value="ghost">Ghost</option><option value="cleaner">Cleaner</option></select></div>
                            </div>
                             <div className="section-title">Target Tech</div>
                             <div className="form-group-inline">
                                 <div className="form-group"><label>Framework</label><select value={frameworkTarget} onChange={e => setField('frameworkTarget', e.target.value as FrameworkTarget)}><option value="react">React</option><option value="vue">Vue</option><option value="svelte">Svelte</option></select></div>
                                 <div className="form-group"><label>Styling</label><select value={stylingTarget} onChange={e => setField('stylingTarget', e.target.value as StylingTarget)}><option value="tailwind">Tailwind</option><option value="plain_css">Plain CSS</option><option value="styled_components">Styled Components</option></select></div>
                                 <div className="form-group"><label>State</label><select value={stateTarget} onChange={e => setField('stateTarget', e.target.value as StateTarget)}><option value="hooks">Hooks</option><option value="redux">Redux</option></select></div>
                             </div>
                            <button onClick={handleDeepDive} disabled={!directive || isFormDisabled}>{getHeistButtonText()}</button>
                        </>
                    ) : (
                        <>
                            <div className="form-group"><label htmlFor="compareDirective">Comparison Directive</label><textarea id="compareDirective" value={compareDirective} onChange={e => setField('compareDirective', e.target.value)} placeholder="e.g., Compare these two components..." /></div>
                            <div className="comparative-grid">
                                <div className="form-group"><label htmlFor="compareCode1">Subject 1</label><textarea id="compareCode1" value={compareCode1} onChange={e => setField('compareCode1', e.target.value)} /></div>
                                <div className="form-group"><label htmlFor="compareCode2">Subject 2</label><textarea id="compareCode2" value={compareCode2} onChange={e => setField('compareCode2', e.target.value)} /></div>
                            </div>
                            <button onClick={handleCompare} disabled={!compareDirective || !compareCode1 || !compareCode2 || appState !== 'IDLE'}>{appState === 'HEISTING' ? 'Analyzing...' : 'Run Comparison'}</button>
                        </>
                    )}
                </div>
            </div>

            {error && <div className="error-message">{error}</div>}
            {liveResult && <StreamingResultCard result={liveResult} />}

            <div className="results-container">
                 {sessionHistory.map(entry => {
                    let content = null;
                    if (entry.type === 'Recon' && reconResult && reconResult.id === entry.id) {
                        content = <ReconCard result={reconResult} onComponentSelect={handleComponentSelect} onApplyTheme={() => {}} />;
                    } else if (entry.type === 'heist' && deepDiveResults[entry.id]) {
                        content = <ResultCard result={deepDiveResults[entry.id]} onTechTagClick={() => {}} onQuickHeist={handleQuickHeist} onOpenSafehouse={(result) => dispatch({ type: 'OPEN_SAFEHOUSE', payload: result })} />;
                    } else if (entry.type === 'refactor' && refactorResults[entry.id]) {
                        content = <RefactorResultCard result={refactorResults[entry.id]} />;
                    } else if (entry.type === 'Compare' && comparativeResults[entry.id]) {
                        content = <ComparativeResultCard result={comparativeResults[entry.id]} />;
                    } else if (entry.type === 'blueprint' && blueprintResults[entry.id]) {
                        content = <BlueprintResultCard result={blueprintResults[entry.id]} />;
                    }
                    return content ? <div key={entry.id} id={entry.id}>{content}</div> : null;
                })}
            </div>

            <HistoryPanel history={renderedHistory} isOpen={isHistoryOpen} onClose={() => dispatch({type: 'TOGGLE_PANEL', payload: {panel: 'history', isOpen: false}})} onJump={() => {}} />
            <CommandPalette isOpen={isCommandPaletteOpen} onClose={() => dispatch({type: 'TOGGLE_PANEL', payload: {panel: 'command', isOpen: false}})} onCommand={handleCommand} />
            <SettingsPanel 
                isOpen={isSettingsOpen} 
                onClose={() => dispatch({type: 'TOGGLE_PANEL', payload: {panel: 'settings', isOpen: false}})}
                theme={theme}
                setTheme={(t) => setField('theme', t)}
                fontSize={fontSize}
                setFontSize={(s) => setField('fontSize', s)}
                layout={layout}
                setLayout={(l) => setField('layout', l)}
            />
            <SafehouseModal
                isOpen={safehouseState.isOpen}
                onClose={() => dispatch({ type: 'CLOSE_SAFEHOUSE' })}
                component={safehouseState.component}
                onGenerateTests={handleGenerateTests}
            />
        </>
    );
}

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);