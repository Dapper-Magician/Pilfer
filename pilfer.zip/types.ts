import { Chat } from "@google/genai";

export interface ColorInfo { hex: string; name: string; }
export interface TypographyInfo { fontFamily: string; usage: string; }
export interface CoreStyleInfo { name: string; code: string; }
export interface ComponentNode { name: string; children?: ComponentNode[]; }

export interface ReconResult { id: string; colorPalette: ColorInfo[]; typography: TypographyInfo[]; coreStyles: CoreStyleInfo[]; pageArchitecture: ComponentNode[]; }
export interface PilferResult { id:string; name: string; techStack: string[]; architecturalNotes: string; code: string; rationale: string; tags: string[]; }
export interface RefactorResult { id: string; name: string; explanation: string; refactoredCode: string; tags: string[]; }
export interface ComparativeResult { id: string; summary: string; subject1: { title: string; notes: string; }, subject2: { title: string; notes: string; } }
export interface BlueprintResult { id: string; name: string; explanation: string; diagram: string; tags: string[]; }
export interface UnitTestResult { testFramework: string; tests: string; explanation: string; }

export type LiveResultType = 'Recon' | AuditType | 'Compare' | 'Blueprint';
export interface LiveResult { id: string; type: LiveResultType; title: string; content: string; }
export interface HistoryEntry { id: string; type: LiveResultType; title: string; }

export type AppStatus = 'IDLE' | 'CASING' | 'HEISTING' | 'PLANNING_HEIST' | 'AWAITING_CONFIRMATION';
export type AnalysisMode = 'single' | 'compare';
export type AuditType = 'heist' | 'accessibility' | 'performance' | 'security' | 'refactor' | 'blueprint';
export type FrameworkTarget = 'react' | 'vue' | 'svelte' | 'web_component' | 'plain_js';
export type StylingTarget = 'plain_css' | 'tailwind' | 'styled_components' | 'css_modules';
export type StateTarget = 'hooks' | 'redux' | 'vuex' | 'svelte_stores' | 'none';
export type Persona = 'ghost' | 'professor' | 'cleaner';
export type Theme = 'default' | 'matrix-green' | 'arcade-neon';
export type Layout = 'default' | 'compact';

export interface AppState {
    appState: AppStatus;
    url: string;
    reconResult: ReconResult | null;
    deepDiveResults: { [id: string]: PilferResult };
    comparativeResults: { [id: string]: ComparativeResult };
    refactorResults: { [id: string]: RefactorResult };
    blueprintResults: { [id: string]: BlueprintResult };
    sessionHistory: HistoryEntry[];
    theme: Theme;
    fontSize: number;
    layout: Layout;
    directive: string;
    pageSource: string;
    code: string;
    apiDocs: string;
    compareCode1: string;
    compareCode2: string;
    compareDirective: string;
    analysisMode: AnalysisMode;
    auditType: AuditType;
    frameworkTarget: FrameworkTarget;
    stylingTarget: StylingTarget;
    stateTarget: StateTarget;
    persona: Persona;
    error: string | null;
    chat: Chat | null;
    chatHistory: any[];
    isHistoryOpen: boolean;
    isCommandPaletteOpen: boolean;
    isSettingsOpen: boolean;
    safehouseState: {
        isOpen: boolean;
        component: PilferResult | null;
    };
    liveResult: LiveResult | null;
    heistPlan: {
        plan: string;
        isAwaitingConfirmation: boolean;
    } | null;
}

export type AppAction =
    | { type: 'SET_FIELD'; payload: { field: keyof AppState; value: any } }
    | { type: 'SET_APP_STATE'; payload: AppStatus }
    | { type: 'SET_CHAT'; payload: Chat }
    | { type: 'LOAD_SESSION'; payload: Partial<AppState> }
    | { type: 'STREAM_START'; payload: { id: string, type: LiveResultType, title: string } }
    | { type: 'STREAM_UPDATE'; payload: string }
    | { type: 'STREAM_END' }
    | { type: 'SET_RECON_RESULT'; payload: ReconResult }
    | { type: 'ADD_RESULT'; payload: { id: string, type: LiveResultType, result: any } }
    | { type: 'ADD_HISTORY_ENTRY'; payload: HistoryEntry }
    | { type: 'SET_ERROR'; payload: string | null }
    | { type: 'TOGGLE_PANEL'; payload: { panel: 'history' | 'command' | 'settings', isOpen: boolean } }
    | { type: 'OPEN_SAFEHOUSE', payload: PilferResult }
    | { type: 'CLOSE_SAFEHOUSE' }
    | { type: 'RESET_SESSION' }
    | { type: 'SET_HEIST_PLAN'; payload: { plan: string; isAwaitingConfirmation: boolean; } }
    | { type: 'CLEAR_HEIST_PLAN' };
